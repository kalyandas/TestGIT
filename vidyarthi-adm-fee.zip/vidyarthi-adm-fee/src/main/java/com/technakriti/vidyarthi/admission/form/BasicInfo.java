package com.technakriti.vidyarthi.admission.form;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import java.util.Date;

/**
 * Created by kalyan on 18-02-2017.
 */
public class BasicInfo {
    @NotEmpty(message = "Admission For is required")
    private String standard;
    @NotEmpty(message = "Stream is required")
    private String stream;
    @NotEmpty(message = "Admission Type is required")
    private String admissionType;
    @NotEmpty(message = "First Name is required")
    private String firstName;
    private String middleName;
    @NotEmpty(message = "Last Name is required")
    private String lastName;
    @NotNull(message = "Date Of Birth is required")
    @Past
    @DateTimeFormat(pattern="yyyy-MM-dd")
    private Date dateOfBirth;
    @NotEmpty(message = "Place Of Birth is required")
    private String placeOfBirth;
    @NotEmpty(message = "Gender is required")
    private String gender;
    @NotEmpty(message = "Nationality is required")
    private String nationality;
    @NotEmpty(message = "Mother Tongue is required")
    private String motherTongue;
    @NotEmpty(message = "Category is required")
    private String category;
    @NotEmpty(message = "Street is required")
    private String presentAddressStreet;
    @NotEmpty(message = "City/Town is required")
    private String presentAddressCity;
    @NotEmpty(message = "District is required")
    private String presentAddressDistrict;
    @NotEmpty(message = "State is required")
    private String presentAddressState;
    @NotEmpty(message = "Pin is required")
    private String presentAddressPin;
    @NotEmpty(message = "Residence Phone is required")
    private String presentAddressResidencePhone;
    @NotEmpty(message = "Residence Mobile is required")
    private String presentAddressResidenceMobile;

    @NotEmpty(message = "Street is required")
    private String permanentAddressStreet;
    @NotEmpty(message = "City/Town is required")
    private String permanentAddressCity;
    @NotEmpty(message = "District is required")
    private String permanentAddressDistrict;
    @NotEmpty(message = "State is required")
    private String permanentAddressState;
    @NotEmpty(message = "Pin is required")
    private String permanentAddressPin;
    @NotEmpty(message = "Residence Phone is required")
    private String permanentAddressResidencePhone;
    @NotEmpty(message = "Residence Mobile is required")
    private String permanentAddressResidenceMobile;

    public String getPresentAddressStreet() {
        return presentAddressStreet;
    }

    public void setPresentAddressStreet(String presentAddressStreet) {
        this.presentAddressStreet = presentAddressStreet;
    }

    public String getPresentAddressCity() {
        return presentAddressCity;
    }

    public void setPresentAddressCity(String presentAddressCity) {
        this.presentAddressCity = presentAddressCity;
    }

    public String getPresentAddressDistrict() {
        return presentAddressDistrict;
    }

    public void setPresentAddressDistrict(String presentAddressDistrict) {
        this.presentAddressDistrict = presentAddressDistrict;
    }

    public String getPresentAddressState() {
        return presentAddressState;
    }

    public void setPresentAddressState(String presentAddressState) {
        this.presentAddressState = presentAddressState;
    }

    public String getPresentAddressPin() {
        return presentAddressPin;
    }

    public void setPresentAddressPin(String presentAddressPin) {
        this.presentAddressPin = presentAddressPin;
    }

    public String getPresentAddressResidencePhone() {
        return presentAddressResidencePhone;
    }

    public void setPresentAddressResidencePhone(String presentAddressResidencePhone) {
        this.presentAddressResidencePhone = presentAddressResidencePhone;
    }

    public String getPresentAddressResidenceMobile() {
        return presentAddressResidenceMobile;
    }

    public void setPresentAddressResidenceMobile(String presentAddressResidenceMobile) {
        this.presentAddressResidenceMobile = presentAddressResidenceMobile;
    }

    public String getPermanentAddressStreet() {
        return permanentAddressStreet;
    }

    public void setPermanentAddressStreet(String permanentAddressStreet) {
        this.permanentAddressStreet = permanentAddressStreet;
    }

    public String getPermanentAddressCity() {
        return permanentAddressCity;
    }

    public void setPermanentAddressCity(String permanentAddressCity) {
        this.permanentAddressCity = permanentAddressCity;
    }

    public String getPermanentAddressDistrict() {
        return permanentAddressDistrict;
    }

    public void setPermanentAddressDistrict(String permanentAddressDistrict) {
        this.permanentAddressDistrict = permanentAddressDistrict;
    }

    public String getPermanentAddressState() {
        return permanentAddressState;
    }

    public void setPermanentAddressState(String permanentAddressState) {
        this.permanentAddressState = permanentAddressState;
    }

    public String getPermanentAddressPin() {
        return permanentAddressPin;
    }

    public void setPermanentAddressPin(String permanentAddressPin) {
        this.permanentAddressPin = permanentAddressPin;
    }

    public String getPermanentAddressResidencePhone() {
        return permanentAddressResidencePhone;
    }

    public void setPermanentAddressResidencePhone(String permanentAddressResidencePhone) {
        this.permanentAddressResidencePhone = permanentAddressResidencePhone;
    }

    public String getPermanentAddressResidenceMobile() {
        return permanentAddressResidenceMobile;
    }

    public void setPermanentAddressResidenceMobile(String permanentAddressResidenceMobile) {
        this.permanentAddressResidenceMobile = permanentAddressResidenceMobile;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public String getMotherTongue() {
        return motherTongue;
    }

    public void setMotherTongue(String motherTongue) {
        this.motherTongue = motherTongue;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getStandard() {
        return standard;
    }

    public void setStandard(String standard) {
        this.standard = standard;
    }

    public String getStream() {
        return stream;
    }

    public void setStream(String stream) {
        this.stream = stream;
    }

    public String getAdmissionType() {
        return admissionType;
    }

    public void setAdmissionType(String admissionType) {
        this.admissionType = admissionType;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getPlaceOfBirth() {
        return placeOfBirth;
    }

    public void setPlaceOfBirth(String placeOfBirth) {
        this.placeOfBirth = placeOfBirth;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }
}
