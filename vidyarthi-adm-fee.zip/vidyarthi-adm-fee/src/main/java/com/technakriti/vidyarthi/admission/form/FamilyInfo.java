package com.technakriti.vidyarthi.admission.form;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

/**
 * Created by kalyan on 19-02-2017.
 */
public class FamilyInfo {
    @NotEmpty(message = "First Name is required")
    private String fatherFirstName;
    private String fatherMiddleName;
    @NotEmpty(message = "Last Name is required")
    private String fatherLastName;
    private String fatherOccupation;
    private String fatherOrganization;
    private boolean fatherSail;
    private String fatherOfficeAddress;
    private String fatherOfficePhone;
    private String fatherResidencePhone;
    private String fatherMobile;
    @Email(message = "Invalid Email")
    private String fatherEmail;

    @NotEmpty(message = "First Name is required")
    private String motherFirstName;
    private String motherMiddleName;
    @NotEmpty(message = "Last Name is required")
    private String motherLastName;
    private String motherOccupation;
    private String motherOrganization;
    private boolean motherSail;
    private String motherOfficeAddress;
    private String motherOfficePhone;
    private String motherResidencePhone;
    private String motherMobile;
    @Email(message = "Invalid Email")
    private String motherEmail;

    private long annualIncome;


    private String child1Name;
    private String child1Class;
    private String child1AdmissionNumber;
    private String child1AdmissionYear;

    private String child2Name;
    private String child2Class;
    private String child2AdmissionNumber;
    private String child2AdmissionYear;

    public String getFatherFirstName() {
        return fatherFirstName;
    }

    public void setFatherFirstName(String fatherFirstName) {
        this.fatherFirstName = fatherFirstName;
    }

    public String getFatherMiddleName() {
        return fatherMiddleName;
    }

    public void setFatherMiddleName(String fatherMiddleName) {
        this.fatherMiddleName = fatherMiddleName;
    }

    public String getFatherLastName() {
        return fatherLastName;
    }

    public void setFatherLastName(String fatherLastName) {
        this.fatherLastName = fatherLastName;
    }

    public String getFatherOccupation() {
        return fatherOccupation;
    }

    public void setFatherOccupation(String fatherOccupation) {
        this.fatherOccupation = fatherOccupation;
    }

    public String getFatherOrganization() {
        return fatherOrganization;
    }

    public void setFatherOrganization(String fatherOrganization) {
        this.fatherOrganization = fatherOrganization;
    }

    public boolean isFatherSail() {
        return fatherSail;
    }

    public void setFatherSail(boolean fatherSail) {
        this.fatherSail = fatherSail;
    }

    public String getFatherOfficeAddress() {
        return fatherOfficeAddress;
    }

    public void setFatherOfficeAddress(String fatherOfficeAddress) {
        this.fatherOfficeAddress = fatherOfficeAddress;
    }

    public String getFatherOfficePhone() {
        return fatherOfficePhone;
    }

    public void setFatherOfficePhone(String fatherOfficePhone) {
        this.fatherOfficePhone = fatherOfficePhone;
    }

    public String getFatherResidencePhone() {
        return fatherResidencePhone;
    }

    public void setFatherResidencePhone(String fatherResidencePhone) {
        this.fatherResidencePhone = fatherResidencePhone;
    }

    public String getFatherMobile() {
        return fatherMobile;
    }

    public void setFatherMobile(String fatherMobile) {
        this.fatherMobile = fatherMobile;
    }

    public String getFatherEmail() {
        return fatherEmail;
    }

    public void setFatherEmail(String fatherEmail) {
        this.fatherEmail = fatherEmail;
    }

    public String getMotherFirstName() {
        return motherFirstName;
    }

    public void setMotherFirstName(String motherFirstName) {
        this.motherFirstName = motherFirstName;
    }

    public String getMotherMiddleName() {
        return motherMiddleName;
    }

    public void setMotherMiddleName(String motherMiddleName) {
        this.motherMiddleName = motherMiddleName;
    }

    public String getMotherLastName() {
        return motherLastName;
    }

    public void setMotherLastName(String motherLastName) {
        this.motherLastName = motherLastName;
    }

    public String getMotherOccupation() {
        return motherOccupation;
    }

    public void setMotherOccupation(String motherOccupation) {
        this.motherOccupation = motherOccupation;
    }

    public String getMotherOrganization() {
        return motherOrganization;
    }

    public void setMotherOrganization(String motherOrganization) {
        this.motherOrganization = motherOrganization;
    }

    public boolean isMotherSail() {
        return motherSail;
    }

    public void setMotherSail(boolean motherSail) {
        this.motherSail = motherSail;
    }

    public String getMotherOfficeAddress() {
        return motherOfficeAddress;
    }

    public void setMotherOfficeAddress(String motherOfficeAddress) {
        this.motherOfficeAddress = motherOfficeAddress;
    }

    public String getMotherOfficePhone() {
        return motherOfficePhone;
    }

    public void setMotherOfficePhone(String motherOfficePhone) {
        this.motherOfficePhone = motherOfficePhone;
    }

    public String getMotherResidencePhone() {
        return motherResidencePhone;
    }

    public void setMotherResidencePhone(String motherResidencePhone) {
        this.motherResidencePhone = motherResidencePhone;
    }

    public String getMotherMobile() {
        return motherMobile;
    }

    public void setMotherMobile(String motherMobile) {
        this.motherMobile = motherMobile;
    }

    public String getMotherEmail() {
        return motherEmail;
    }

    public void setMotherEmail(String motherEmail) {
        this.motherEmail = motherEmail;
    }

    public long getAnnualIncome() {
        return annualIncome;
    }

    public void setAnnualIncome(long annualIncome) {
        this.annualIncome = annualIncome;
    }

    public String getChild1Name() {
        return child1Name;
    }

    public void setChild1Name(String child1Name) {
        this.child1Name = child1Name;
    }

    public String getChild1Class() {
        return child1Class;
    }

    public void setChild1Class(String child1Class) {
        this.child1Class = child1Class;
    }

    public String getChild1AdmissionNumber() {
        return child1AdmissionNumber;
    }

    public void setChild1AdmissionNumber(String child1AdmissionNumber) {
        this.child1AdmissionNumber = child1AdmissionNumber;
    }

    public String getChild1AdmissionYear() {
        return child1AdmissionYear;
    }

    public void setChild1AdmissionYear(String child1AdmissionYear) {
        this.child1AdmissionYear = child1AdmissionYear;
    }

    public String getChild2Name() {
        return child2Name;
    }

    public void setChild2Name(String child2Name) {
        this.child2Name = child2Name;
    }

    public String getChild2Class() {
        return child2Class;
    }

    public void setChild2Class(String child2Class) {
        this.child2Class = child2Class;
    }

    public String getChild2AdmissionNumber() {
        return child2AdmissionNumber;
    }

    public void setChild2AdmissionNumber(String child2AdmissionNumber) {
        this.child2AdmissionNumber = child2AdmissionNumber;
    }

    public String getChild2AdmissionYear() {
        return child2AdmissionYear;
    }

    public void setChild2AdmissionYear(String child2AdmissionYear) {
        this.child2AdmissionYear = child2AdmissionYear;
    }
}
