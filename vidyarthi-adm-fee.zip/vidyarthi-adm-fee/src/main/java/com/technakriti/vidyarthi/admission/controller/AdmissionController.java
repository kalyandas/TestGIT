package com.technakriti.vidyarthi.admission.controller;

import com.technakriti.vidyarthi.admission.form.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by kalyan on 18-02-2017.
 */
@Controller
public class AdmissionController {

    @Autowired
    private HttpSession httpSession;

    @Autowired
    BasicInfoValidator basicInfoValidator;

//    @InitBinder
//    public void initBinder(WebDataBinder webDataBinder){
//        webDataBinder.setValidator(basicInfoValidator);
//    }

    @RequestMapping("/admission")
    public String step1(Model model) {
        this.initStep1(model);
        model.addAttribute(new BasicInfo());
       return "admission1";
    }


    @RequestMapping(value = "/admission2", method = RequestMethod.POST)
    public String step2(Model model, @ModelAttribute("basicInfo") @Valid BasicInfo basicInfo, BindingResult result) {

        if (result.hasErrors()) {
            this.initStep1(model);
            basicInfoValidator.validate(basicInfo,result);
            System.out.println(result.getFieldErrors());
            return "admission1";

        } else {
            //System.out.println(basicInfo.getFirstName());
            httpSession.setAttribute("basicInfo",basicInfo);
            model.addAttribute(new FamilyInfo());
            return "admission2";
        }

    }

    @RequestMapping(value = "/admission3", method = RequestMethod.POST)
    public String step3(Model model, @ModelAttribute("familyInfo") @Valid FamilyInfo familyInfo, BindingResult result) {

        if (result.hasErrors()) {
            //this.initStep1(model);
            return "admission2";

        } else {
            //System.out.println(basicInfo.getFirstName());
            httpSession.setAttribute("familyInfo",familyInfo);
            BasicInfo basicInfo = (BasicInfo)httpSession.getAttribute("basicInfo");
            if(basicInfo.getStandard().equalsIgnoreCase("Pre-Nursery")
                    || basicInfo.getStandard().equalsIgnoreCase("Nursery")){
                model.addAttribute("eduInfo",new EducationInfo());
            }

            return "admission3";
        }

    }


    @RequestMapping(value = "/admission4", method = RequestMethod.POST)
    public String step4(Model model, @ModelAttribute("eduInfo") @Valid EducationInfo educationInfo, BindingResult result) {

        if (result.hasErrors()) {
            //this.initStep1(model);
            return "admission3";

        } else {
            return "admission4";
        }

    }


    private void initStep1(Model model){
        List<String> standards = new ArrayList<String>();
        standards.add("Pre-Nursery");
        standards.add("Nursery");
        standards.add("Class XII");
        model.addAttribute("standards",standards);

        List<String> streams = new ArrayList<String>();
        streams.add("All");
        streams.add("Science");
        streams.add("Commerce");
        model.addAttribute("streams",streams);
    }



    @RequestMapping("/test")
    public ModelAndView showHomePage() {
        return new ModelAndView("test", "test", new Test());
    }


    @RequestMapping(value = "/saveTest", method = RequestMethod.POST)
    public String addCustomer(@ModelAttribute("test") @Valid Test test, BindingResult result) {

        if (result.hasErrors()) {

            return "test";

        } else {
            System.out.println(test.getName());
            System.out.println(test.getLastName());
            return "result";
        }

    }
}
