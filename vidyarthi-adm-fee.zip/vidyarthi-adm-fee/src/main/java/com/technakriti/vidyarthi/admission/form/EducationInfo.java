package com.technakriti.vidyarthi.admission.form;

import org.hibernate.validator.constraints.NotEmpty;

/**
 * Created by kalyan on 24-02-2017.
 */
public class EducationInfo {
    @NotEmpty(message = "Please choose a language")
    private String languageChoice;

    public String getLanguageChoice() {
        return languageChoice;
    }

    public void setLanguageChoice(String languageChoice) {
        this.languageChoice = languageChoice;
    }
}
