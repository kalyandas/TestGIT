package com.technakriti.vidyarthi.admission.form;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by kalyan on 23-02-2017.
 */
@Component
public class BasicInfoValidator implements Validator {
    SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
    @Override
    public boolean supports(Class<?> aClass) {
        return BasicInfo.class.isAssignableFrom(aClass);
    }

    @Override
    public void validate(Object o, Errors errors) {

        BasicInfo basicInfo = (BasicInfo)o;
        try {
            if(basicInfo.getDateOfBirth()!=null &&
                    dateFormatter.parse("2014-01-01").after(basicInfo.getDateOfBirth())){
                System.out.println("Error");
                errors.reject("dateOfBirth","Date of Birth should be before 2014");
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        //basicInfo.getDateOfBirth();
    }
}
